import React from 'react';
import { PureComponent } from 'react';

class Ssdashboard extends PureComponent {
    
    render() { 
        return ( 
            <>
            <div className="ssdashboard">
                hiii this is dashboard page
            </div>
            </>
         );
    }
}
 
export default Ssdashboard;