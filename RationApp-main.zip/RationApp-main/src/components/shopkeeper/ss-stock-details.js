import React from 'react';
import { PureComponent } from 'react';

class Ssstockdetails extends PureComponent {
    
    render() { 
        return ( 
            <>
            <div className="ssstockdetails">
                
            </div>
            </>
         );
    }
}
 
export default Ssstockdetails;