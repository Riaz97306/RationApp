import React from 'react';
import { PureComponent } from 'react';

class Ssuserdetails extends PureComponent {
    
    render() { 
        return ( 
            <>
            <div className="ssuserdetails">
                hiii this is user details page
            </div>
            </>
         );
    }
}
 
export default Ssuserdetails;