import React from 'react';
import { PureComponent } from 'react';

class Contact extends PureComponent {
    render(){
        return ( 
            <>
            
            <div className="contact m-3" style={{textAlign:'left'}}>
                <h1>Contact Us</h1> <br/>
                <h3>HelpLine Numbers :</h3>
                <h5>Controller of Rationing & Director of Civil Supplies email id :- 022-22852814</h5>
                <h5>Official email id :- dycor.ho-mum@gov.in</h5>
                <h5>Mantralaya - Telephone No.: 022-22024243</h5>
                <h5>Public Distribution - Tollfree Helpline No.: 1967 or 1800-22-4950</h5>
                <br/>
                <h6>For More Details Visit :- <a href="http://controllerofrationing-mumbai.gov.in/index.html">Click here</a></h6>
            </div>
            </>
        );
    }
}
 
export default Contact;