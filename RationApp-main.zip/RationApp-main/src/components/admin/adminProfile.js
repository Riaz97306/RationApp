import React from 'react';
import { PureComponent } from 'react';

class AdminProfile extends PureComponent {
    
    render() { 
        return ( 
            <>
            <div className="ssdashboard">
                hiii this is profile page
            </div>
            </>
         );
    }
}
 
export default AdminProfile;