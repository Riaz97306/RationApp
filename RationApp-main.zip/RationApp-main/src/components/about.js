import React from 'react';
import { PureComponent } from 'react';


class About extends PureComponent {
    render(){
        return ( 
            <>
            <div className="about m-3" style={{textAlign:'left'}}>
            <h1>About Us</h1>
                <p className="vertical-center">
                In April, 1966 Statutory Rationing was introduced in Greater Mumbai and the Industrial complex of Thana which included the Thana Town, Kalyan, Belapur, Ulhasnagar and Ambernath. All these areas are operating the Rationing Scheme under provisions of the Maharashtra food grain (second) Ration Order of 1966.
                <br/> The Rationing Organization is headed by the Controller of Rationing.The team comprises of 2 Deputy Controllers who assist The Controller in supervising Indent, Shops, Establishments, Administration, Accounts, General, Enforcement, Kerosene etc. There are other five Deputy Controller of Rationing that are incharge of each region, 04 in Mumbai and 01 in Thane.
                Genral control is managed by Food and Civil Supplies department & they also issue directives in policy & other realted matters. Mumbai & Thane area is serviced by 46 Rationing offices. In each Rationing office the day to day functioning is supervised by 1 to 2 Assistant Rationing Officers & is supervised by a Rationing. Each Rationing Office works as Nodal Agency for issue / cancellation /changes in Ration Cards.</p>
                <h2>Aim of the system</h2>
                <p>Our focus is to reduce the corruption in the ration distribution system. we all want a trasparent system so no one can cheat with ration system</p>
            </div>
            </>
        );
    }
}
 
export default About;